#include <iostream>

int main() {

	std::cout << "Input your drink choice by number:" << std::endl;
	std::cout << "1. Water" << std::endl;
	std::cout << "2. Sprite" << std::endl;
	std::cout << "3. Orange Juice" << std::endl;
	std::cout << "4. Lemon Tea" << std::endl;
	std::cout << "5. Milk" << std::endl;
	int inpNum;
	std::cin >> inpNum;

	switch (inpNum) {
	case 1: {
		std::cout << "Water outputting.." << std::endl;
		break;
	}
	case 2: {
		std::cout << "Sprite outputting.." << std::endl;
		break;
	}
	case 3: {
		std::cout << "Orange Juice outputting.." << std::endl;
		break;
	}
	case 4: {
		std::cout << "Lemon Tea outputting.." << std::endl;
		break;
	}
	case 5: {
		std::cout << "Milk outputting.." << std::endl;
		break;
	}
	default:
	{
		std::cout << "Invalid choice" << std::endl;
		break;
	}
	}
	return 0;
}
