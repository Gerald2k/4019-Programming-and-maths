#include <iostream>

int main() {

	std::cout << "Input your grade!" << std::endl;
	int gradeNum;
	std::cin >> gradeNum;

	if (gradeNum >= 80) {
		std::cout << "You have an A!" << std::endl;
	}
	else if (gradeNum >= 70){
		std::cout << "You have a B!" << std::endl;
	}
	else if (gradeNum >= 60){
		std::cout << "You have a C!" << std::endl;
	}
	else if (gradeNum >= 50) {
		std::cout << "You have a D!" << std::endl;
	}
	else if (gradeNum >= 40) {
		std::cout << "You have a E!" << std::endl;
	}
	else if (gradeNum >= 1) {
		std::cout << "You have a F!" << std::endl;
	}
	else if (gradeNum == 0) {
		std::cout << "You have a U!" << std::endl;
	}
	else
	{
		std::cout << "Invalid input!" << std::endl;
	}
	return 0;
}
