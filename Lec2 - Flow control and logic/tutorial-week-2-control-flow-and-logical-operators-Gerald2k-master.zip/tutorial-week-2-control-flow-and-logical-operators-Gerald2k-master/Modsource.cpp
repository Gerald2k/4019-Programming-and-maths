#include <iostream>

int main() {

	std::cout << "Input your positive number!" << std::endl;
	int inpNum;
	std::cin >> inpNum;

	if (inpNum == 0) {
		std::cout << "You have entered 0!" << std::endl;
	}
	else if (inpNum % 2 == 0){
		std::cout << "You have a even number!" << std::endl;
	}
	else if (inpNum % 2 != 0){
		std::cout << "You have a odd number!" << std::endl;
	}
	else
	{
		std::cout << "Invalid input!" << std::endl;
	}
	return 0;
}
